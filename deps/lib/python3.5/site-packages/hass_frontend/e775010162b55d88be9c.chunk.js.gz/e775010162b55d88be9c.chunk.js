(window.webpackJsonp=window.webpackJsonp||[]).push([[16],{603:function(e,s,t){"use strict";t.r(s);var a=t(0),r=t(2);t(159),customElements.define("ha-panel-kiosk",class extends r.a{static get template(){return a["a"]`
    <partial-cards
      id='kiosk-states'
      hass='[[hass]]'
      show-menu
      route='[[route]]'
      panel-visible
    ></partial-cards>
    `}static get properties(){return{hass:Object,route:Object}}})}}]);
//# sourceMappingURL=e775010162b55d88be9c.chunk.js.map